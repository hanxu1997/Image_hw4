# Image_hw4

## 15331416 赵寒旭 15级数字媒体技术

### 指南
文件结构描述和代码运行指南均在report文件夹下实验报告第5部分附录中详细描述。

### 小注
运行 
ImageFilter.m
ImageNoise.m
ImageEqualize.m
三个代码文件，
可以得到所有题目的输出结果。

ImageNoise由于多次调用滤波函数，run后可能需要等待十几秒。
